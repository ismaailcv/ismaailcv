﻿using Microsoft.EntityFrameworkCore;
using NewRegistrationForm.Models;

namespace NewRegistrationForm.Dbcontexts
{
    public class RegistrationDbContext:DbContext
    {
        public DbSet<Registration> Registrations { get; set; }
        public DbSet<Profile> Profiles { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer("Server=DESKTOP-119NHHV\\SQLEXPRESS;Encrypt=True;Database=NewRegistrationDb;Trusted_Connection=True;TrustServerCertificate=True");
        }
    }
}
