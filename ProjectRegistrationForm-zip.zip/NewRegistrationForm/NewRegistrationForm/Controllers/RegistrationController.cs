﻿using System.Net.Mail;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using NewRegistrationForm.Dbcontexts;
using NewRegistrationForm.Models;
using SendGrid;
using SendGrid.Helpers.Mail;


namespace NewRegistrationForm.Controllers
{
    public class RegistrationController : Controller
    {
        RegistrationDbContext context;
        public RegistrationController(RegistrationDbContext context)
        {
            this.context=context;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(Registration model)
        {
            context.Registrations.Add(model);
            context.SaveChanges();

            if (model.Id > 0)
            {
                var verificationLink = Url.Action("VerifyEmail", "Registration", new { id = model.Id }, Request.Scheme);

                await SendVerificationEmail(model.Email, verificationLink);
            }

            return RedirectToAction("Index", "Home");
        }
        public ActionResult Password()
        {
            return View();
        }

        private async Task SendVerificationEmail(string email, string verificationLink)
        {
            //I Used Sendgrid
            var apiKey = "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";
            var client = new SendGridClient(apiKey);

            var from = new EmailAddress("ismaailcv130594@outlook.com", "Ismail");
            var to = new EmailAddress(email);
            var subject = "Email Verification";
            var plainTextContent = $"Please click the following link to verify your email: {verificationLink}";
            var htmlContent = $"<p>Please click the following link to verify your email: <a href='{verificationLink}'>{verificationLink}</a></p>";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);

            await client.SendEmailAsync(msg);
        }

        //once the user clicks the url in mail, this action will get triggered
        public IActionResult VerifyEmail(int id)
        {
            var registrationsf = context.Registrations.Where(x => x.Id == id).FirstOrDefault();
            if (registrationsf != null)
            {

                // Pass the registration ID to the view
                ViewBag.RegistrationId = id;
                return View();
            }
            
            // Registration not found, handle the error scenario (e.g., show an error message)
            return RedirectToAction("Index", "Home");
        }



        [HttpPost]
        public IActionResult SetPassword(int registrationId, string password, string confirmPassword)
        {
            // Retrieve the registration from the database based on the ID
            var registration = context.Registrations.FirstOrDefault(r => r.Id == registrationId);
            if (registration == null)
            {
                // Registration not found, handle the error scenario (e.g., show an error message)
                return RedirectToAction("Index", "Home");
            }

            // Check if the password and confirm password match
            if (password == confirmPassword)
            {
                // Set the password and update the registration's verification status
                registration.Password = password;
                registration.IsEmailVerified = true;
                context.SaveChanges();

                // Redirect to a success page or any other desired action
                return RedirectToAction("Success", "Registration");
            }
            else
            {
                // Password and confirm password don't match, handle the error scenario (e.g., show an error message)
                return RedirectToAction("Index", "Home");
            }

        }

        public IActionResult Login()
        {
            return View();
        }
        //once the user logins with username and password this action will get triggered
        [HttpPost]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var registration = context.Registrations.FirstOrDefault(r => r.Email == model.Email && r.Password == model.Password);

                if (registration != null)
                {
                    // Redirect to the profile page
                    return RedirectToAction("Profile", new { id = registration.Id });
                }
                else
                {
                    // Login failed, handle the error scenario (e.g., show an error message)
                    ModelState.AddModelError("", "Invalid email or password.");
                }
            }

            return View(model);
        }


        public IActionResult Profile(int id)
        {
            var registration = context.Registrations.FirstOrDefault(r => r.Id == id);
            if (registration == null)
            {
                return RedirectToAction("Index", "Home");
            }

            var viewModel = new ProfileViewModel
            {
                Name = registration.Name,
                Email = registration.Email,
                Mobile = registration.Mobile,
                States = new List<string> { "Telangana", "Delhi", "Uttar Pradesh", "Kerala", "Karnataka" },
                Cities = new List<string> { "Hyderabad", "Bangalore", "Chennai" }
            };

            return View(viewModel);
        }

    }

}
