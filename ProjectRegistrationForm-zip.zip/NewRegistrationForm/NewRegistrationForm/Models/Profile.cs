﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace NewRegistrationForm.Models
{
    public class Profile
    {
        [Key]
        [ForeignKey(nameof(Registration))]
        public int Id { get; set; }

        public string Address { get; set; }

        public string State { get; set; }

        public string City { get; set; }

        public string MobileNo { get; set; }

        public string Resume { get; set; }

        public string Photo { get; set; }

        public virtual Registration Registration { get; set; }
    }
}
