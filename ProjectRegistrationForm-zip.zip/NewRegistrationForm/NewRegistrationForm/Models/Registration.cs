﻿using System.ComponentModel.DataAnnotations;

namespace NewRegistrationForm.Models
{
    public class Registration
    {
        [Key]
        public int? Id { get; set; }

        [Required]
        public string? Name { get; set; }

        [Required]
        public string? Mobile { get; set; }

        [Required]
        [EmailAddress]
        public string? Email { get; set; }

        public bool? IsEmailVerified { get; set; }

        public string? Password { get; set; }
        public virtual Profile? Profile { get; set; }
    }
}
