﻿using System.ComponentModel.DataAnnotations;

namespace NewRegistrationForm.Models
{
    public class ProfileViewModel
    {
        // Registration details
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }

        // Profile details
        [Required(ErrorMessage = "Address is required.")]
        public string Address { get; set; }

        [Required(ErrorMessage = "State is required.")]
        public string SelectedState { get; set; }

        [Required(ErrorMessage = "City is required.")]
        public string SelectedCity { get; set; }

        public List<string> States { get; set; }
        public List<string> Cities { get; set; }

        [Required(ErrorMessage = "Mobile number is required.")]
        public string MobileNo { get; set; }
    }
}
